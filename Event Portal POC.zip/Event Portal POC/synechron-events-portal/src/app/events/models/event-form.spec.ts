import { EventForm } from './event-form';

describe('EventForm', () => {
  it('should create an instance', () => {
    expect(new EventForm()).toBeTruthy();
  });
});
