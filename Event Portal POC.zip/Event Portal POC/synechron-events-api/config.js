module.exports = {
    secretKey: "syneblrdevfinancesuperdev"
}